-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июн 30 2019 г., 15:24
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `proton02_winst`
--

-- --------------------------------------------------------

--
-- Структура таблицы `image_size`
--
-- Создание: Июн 27 2019 г., 12:30
-- Последнее обновление: Июн 27 2019 г., 12:51
--

DROP TABLE IF EXISTS `image_size`;
CREATE TABLE `image_size` (
  `id` int(5) NOT NULL,
  `size_code` char(20) NOT NULL,
  `width` int(10) NOT NULL,
  `height` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `image_size`
--

INSERT INTO `image_size` (`id`, `size_code`, `width`, `height`) VALUES
(1, 'big', 800, 600),
(2, 'med', 640, 480),
(3, 'min', 320, 240),
(4, 'mic', 150, 150);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `image_size`
--
ALTER TABLE `image_size`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
